declare module '*.css' 
